/*BCP-database-config*/
const DATABASE_NAME = 'todo_express';
const USERNAME = 'root';
const PASSWORD = 'root';
const HOST = 'localhost';
const DIALECT = 'mysql';
/*ECP-database-config*/

module.exports = {
  DATABASE_NAME: DATABASE_NAME,
  USERNAME: USERNAME,
  PASSWORD: PASSWORD,
  HOST: HOST,
  DIALECT: DIALECT
};